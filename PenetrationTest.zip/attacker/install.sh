#!/bin/sh
set -e

# 1. パッケージインデックスの更新
apk update

# 2. 公式パッケージからツールをインストール
# dnsutilsはbind-tools、iputils-pingはiputilsに含まれます
apk add --no-cache \
    curl \
    iproute2 \
    nmap \
    bind-tools \
    iputils \
    openssh-client \
    hydra \
    john

# 3. hping3のインストール
apk add hping3 --update-cache --repository http://dl-cdn.alpinelinux.org/alpine/edge/testing

# 4. 不要になったキャッシュの削除（コンテナ軽量化）
rm -rf /tmp/hping /var/cache/apk/*

echo "すべてのツールのインストールが完了しました。"
