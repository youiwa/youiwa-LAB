#!/bin/bash
# SSHサーバセットアップ用スクリプト（Ubuntu 24.04）

apt update
# 各種ツールなどをインストール
apt install -y curl iproute2 nmap dnsutils iputils-ping vim tshark hping3


# SSHサーバのインストールと初期設定
apt install -y openssh-server \
    && mkdir /var/run/sshd

# rsyslogのインストール（SSHログの保存）
apt install -y rsyslog supervisor

# ログ設定：コンテナ内ではカーネルログ(imklog)を読み込めないため無効化する
sed -i '/imklog/s/^/#/' /etc/rsyslog.conf

# キャッシュ削除（軽量化）
apt clean

# 不要なパッケージリスト削除（イメージサイズ削減）
rm -rf /var/lib/apt/lists/*

# 脆弱性の追加
## sshd_configの修正: rootログインとパスワード認証を許可（脆弱性）
sed -i 's/#PermitRootLogin prohibit-password/PermitRootLogin yes/' /etc/ssh/sshd_config
sed -i 's/#PasswordAuthentication yes/PasswordAuthentication yes/' /etc/ssh/sshd_config
sed -i 's/#MaxStartups 10:30:10/MaxStartups 10000:30:10000/' /etc/ssh/sshd_config
## SSHの認証試行回数とログイン猶予時間を緩和（脆弱性）
echo "MaxAuthTries 10000" >> /etc/ssh/sshd_config
echo "LoginGraceTime 0" >> /etc/ssh/sshd_config
## shadowファイルの権限を緩和（脆弱性）
chmod 644 /etc/shadow
## PAM認証の応答遅延を無効化（脆弱性：ブルートフォースアタックの高速化）
PAM_FILE="/etc/pam.d/common-auth"
if [ -f "$PAM_FILE" ]; then
    # pam_unix.so の行の末尾に nodelay を追加
    sed -i 's/pam_unix.so nullok/pam_unix.so nullok nodelay/' "$PAM_FILE"
fi
## パスワード暗号化方式をSHA-512に切り替え
### Linuxシステム全体のパスワード暗号化設定（PAM）を yescrypt から sha512 に強制変更
sed -i 's/yescrypt/sha512/' /etc/pam.d/common-password

# スーパーユーザの追加とパスワード設定
## 既存の ubuntu ユーザーを削除（UID 1000を解放）
if id "ubuntu" >/dev/null 2>&1; then
    userdel -r ubuntu
fi
useradd -rm -d /home/admin -s /bin/bash -g root -G sudo -u 1000 admin \
    && echo 'admin:123abc' | chpasswd

# 一般ユーザの追加とパスワード設定
groupadd -g 1001 sshgroup \
    && useradd -rm -d /home/user -s /bin/bash -g sshgroup -u 1001 user \
    && echo 'user:1234' | chpasswd

# --- 演習用フラグの配置 ---

# 1. 一般ユーザ(user)のホームディレクトリに移動してフラグを作成
FLAG_PATH="/home/user/flag.txt"
echo "おめでとう！ミッションクリアです！" > $FLAG_PATH
echo "君は見事にパスワードをクラッキングして、サーバーに潜入しました。" >> $FLAG_PATH
# echo "秘密のフラグ：FLAG{高知高専、最高！！}" >> $FLAG_PATH

# 2. 所有者を user に変更し、権限を設定（userだけが読めるようにする）
chown user:sshgroup $FLAG_PATH
chmod 600 $FLAG_PATH

# (オプション) 管理者(admin)のホームディレクトリにも別のフラグを置く場合
ADMIN_FLAG="/home/admin/admin_flag.txt"
echo "すごい！管理者のパスワード(123abc)も破ったのか！" > $ADMIN_FLAG
echo "特権フラグ：FLAG{super_admin_unlock_9999}" >> $ADMIN_FLAG
chown admin:root $ADMIN_FLAG
chmod 600 $ADMIN_FLAG

echo "フラグの配置が完了しました。"